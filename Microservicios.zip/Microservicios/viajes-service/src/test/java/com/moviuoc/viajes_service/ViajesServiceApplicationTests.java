package com.moviuoc.viajes_service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ViajesServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
