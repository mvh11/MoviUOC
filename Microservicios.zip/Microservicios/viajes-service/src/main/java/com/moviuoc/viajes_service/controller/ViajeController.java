package com.moviuoc.viajes_service.controller;

import com.moviuoc.viajes_service.model.Viaje;
import com.moviuoc.viajes_service.repository.ViajeRepository;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/viajes")
@CrossOrigin(origins = "*")
public class ViajeController {

    private final ViajeRepository repo;

    public ViajeController(ViajeRepository repo) {
        this.repo = repo;
    }

    @GetMapping
    public List<Viaje> getAll() {
        return repo.findAll();
    }

    @PostMapping
    public Viaje create(@RequestBody Viaje viaje) {
        viaje.setId(null);
        return repo.save(viaje);
    }
}
