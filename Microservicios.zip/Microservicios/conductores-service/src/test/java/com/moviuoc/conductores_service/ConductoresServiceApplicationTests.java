package com.moviuoc.conductores_service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ConductoresServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
