package com.moviuoc.conductores_service.controller;

import com.moviuoc.conductores_service.model.Conductor;
import com.moviuoc.conductores_service.repository.ConductorRepository;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/conductores")
@CrossOrigin(origins = "*")
public class ConductorController {

    private final ConductorRepository repo;

    public ConductorController(ConductorRepository repo) {
        this.repo = repo;
    }

    @GetMapping
    public List<Conductor> getAll() {
        return repo.findAll();
    }

    @PostMapping
    public Conductor create(@RequestBody Conductor c) {
        c.setId(null);
        return repo.save(c);
    }
}
