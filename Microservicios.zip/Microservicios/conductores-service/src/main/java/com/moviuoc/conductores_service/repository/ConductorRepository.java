package com.moviuoc.conductores_service.repository;

import com.moviuoc.conductores_service.model.Conductor;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ConductorRepository extends JpaRepository<Conductor, Long> {
}
